import { useRef, useEffect, useState } from 'react'
import { useFBX, useAnimations } from '@react-three/drei'
import { LoopRepeat } from 'three'

function WolfModel() {
  const group = useRef()
  const [currentAnimation, setCurrentAnimation] = useState('idle_1')
  
  // Load all animation files
  const idleWolf = useFBX('/wolfModel/idleWolf.fbx')
  const angryWolf = useFBX('/wolfModel/Angry.fbx')
  const wavingWolf = useFBX('/wolfModel/Waving.fbx')

  // Create unique animations by renaming them
  const processAnimations = (animations, prefix) => {
    return animations.map((anim, index) => {
      // Clone the animation to avoid modifying the original
      const clonedAnim = anim.clone()
      // Give it a unique name based on the source
      clonedAnim.name = `${prefix}_${index}`
      clonedAnim.sourceType = prefix
      return clonedAnim
    })
  }

  // Process all animations with unique names
  const allAnimations = [
    ...processAnimations(idleWolf.animations, 'idle'),
    ...processAnimations(angryWolf.animations, 'angry'),
    ...processAnimations(wavingWolf.animations, 'waving')
  ]

  const { actions } = useAnimations(allAnimations, group)

  // Set default animation to idle
  useEffect(() => {
    const idleAnimationKey = Object.keys(actions).find(key => key.startsWith('idle_'))
    if (idleAnimationKey && !currentAnimation) {
      setCurrentAnimation(idleAnimationKey)
    }
  }, [actions, currentAnimation])

  useEffect(() => {
    // Stop all current actions
    Object.keys(actions).forEach(actionName => {
      if (actions[actionName]) {
        actions[actionName].stop()
      }
    })

    // Play the current animation (default: idle)
    if (currentAnimation && actions[currentAnimation]) {
      actions[currentAnimation]
        .reset()
        .fadeIn(0.3)
        .setLoop(LoopRepeat, Infinity)
        .play()
    }

    return () => {
      // Cleanup
      Object.keys(actions).forEach(actionName => {
        if (actions[actionName]) {
          actions[actionName].stop()
        }
      })
    }
  }, [actions, currentAnimation])

  return (
    <group ref={group}>
      <primitive
        object={idleWolf}
        scale={0.01}
        position={[-3.5, 1.1, 0]} 
        rotation={[0, 2, 0]}
        castShadow
        receiveShadow
      />
    </group>
  )
}

export default WolfModel 