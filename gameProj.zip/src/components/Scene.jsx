import { useGLTF } from '@react-three/drei'
import WolfModel from './WolfModel'
import CatModel from './CatModel'
import { useGame } from './GameContext'

function GandalfModel() {
  const { scene } = useGLTF('/forGandalf.glb')

  return (
    <primitive
      object={scene}
      scale={1}
      position={[0, -1, 0]}
      castShadow
      receiveShadow
    />
  )
}

function Scene() {
  const { gameState } = useGame()

  return (
    <group>
      {/* Main Gandalf Model (Bridge) */}
      <GandalfModel />

      {/* Wolf Model with Animations */}
      <WolfModel />

      {/* Cat Model with Level Progression */}
      <CatModel 
        position={gameState.catPosition}
        isMoving={gameState.isMoving}
        targetPosition={gameState.catPosition}
      />

      {/* Ground Plane */}
      <mesh
        rotation={[-Math.PI / 2, 0, 0]}
        position={[0, -1.5, 0]}
        receiveShadow
      >
        {/* <planeGeometry args={[20, 20]} />
        <meshStandardMaterial color="#f8f9fa" /> */}
      </mesh>
    </group>
  )
}

export default Scene 