import { useRef, useEffect } from 'react'
import { useGLTF, useAnimations } from '@react-three/drei'
import { LoopRepeat } from 'three'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'

function CatModel({ position = [3, 1.1, -0.9], isMoving = false, targetPosition = null }) {
  const group = useRef()
  const currentPosition = useRef(new THREE.Vector3(...position))
  const targetPos = useRef(new THREE.Vector3(...position))
  
  // Load the cat model
  const { scene, animations } = useGLTF('/catModel/somali_cat_animated_ver_1.2.glb')
  const { actions } = useAnimations(animations, group)

  // Console log all available animations
  useEffect(() => {
    if (animations.length > 0) {
      console.log('🐱 Available Cat Animations:')
      animations.forEach((animation, index) => {
        console.log(`${index + 1}. ${animation.name} (duration: ${animation.duration.toFixed(2)}s)`)
      })
      console.log('Total animations:', animations.length)
    }
  }, [animations])

  // Update target position when position prop changes
  useEffect(() => {
    if (targetPosition) {
      targetPos.current.set(...targetPosition)
    } else {
      targetPos.current.set(...position)
    }
  }, [position, targetPosition])

  // Animation control based on movement state
  useEffect(() => {
    if (animations.length === 0) return

    // Find available animations
    const walkAnimation = animations.find(anim => 
      anim.name.toLowerCase().includes('walk') || 
      anim.name.toLowerCase().includes('run') ||
      anim.name.toLowerCase().includes('move')
    )
    
    const idleAnimation = animations.find(anim => 
      anim.name.toLowerCase().includes('idle') || 
      anim.name.toLowerCase().includes('rest') ||
      anim.name.toLowerCase().includes('stand')
    )

    // Stop all current animations
    Object.keys(actions).forEach(actionName => {
      if (actions[actionName]) {
        actions[actionName].fadeOut(0.3)
      }
    })

    // Play appropriate animation
    if (isMoving && walkAnimation) {
      console.log(`🐱 Playing walk animation: ${walkAnimation.name}`)
      actions[walkAnimation.name]
        .reset()
        .fadeIn(0.3)
        .setLoop(LoopRepeat, Infinity)
        .play()
    } else if (!isMoving && idleAnimation) {
      console.log(`🐱 Playing idle animation: ${idleAnimation.name}`)
      actions[idleAnimation.name]
        .reset()
        .fadeIn(0.3)
        .setLoop(LoopRepeat, Infinity)
        .play()
    } else {
      // Fallback to first animation
      const fallbackAnimation = animations[0]
      if (fallbackAnimation && actions[fallbackAnimation.name]) {
        console.log(`🐱 Playing fallback animation: ${fallbackAnimation.name}`)
        actions[fallbackAnimation.name]
          .reset()
          .fadeIn(0.3)
          .setLoop(LoopRepeat, Infinity)
          .play()
      }
    }

    return () => {
      // Cleanup on unmount
      Object.keys(actions).forEach(actionName => {
        if (actions[actionName]) {
          actions[actionName].stop()
        }
      })
    }
  }, [actions, animations, isMoving])

  // Smooth movement animation
  useFrame((state, delta) => {
    if (group.current) {
      // Lerp towards target position
      const lerpFactor = delta * 2 // Adjust speed as needed
      currentPosition.current.lerp(targetPos.current, lerpFactor)
      
      // Update the group position
      group.current.position.copy(currentPosition.current)
    }
  })

  return (
    <group ref={group}>
      <primitive
        object={scene}
        scale={0.1}
        rotation={[0, Math.PI / 2, 0]}
        castShadow
        receiveShadow
      />
    </group>
  )
}

// Preload the model
useGLTF.preload('/catModel/somali_cat_animated_ver_1.2.glb')

export default CatModel 