import React, { useState, useEffect, useRef } from 'react';
import NPCApiService from '../services/npcApi';
import { useGame } from './GameContext';

const NPCChat = () => {
  const [npcService] = useState(() => new NPCApiService('let-me-pass'));
  const [messages, setMessages] = useState([]);
  const [inputMessage, setInputMessage] = useState('');
  const [currentNPCId, setCurrentNPCId] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isStreaming, setIsStreaming] = useState(false);
  const [showDebug, setShowDebug] = useState(false); // Hide debug by default since it's working
  // Use shared game state from context
  const { gameState, startGame, updateGameMetrics, moveToNextLevel } = useGame();
  const streamRef = useRef(null);

  // Bridge Guardian Welcome Message
  useEffect(() => {
    setMessages([{
      id: Date.now(),
      text: `🌲🐺 Welcome to Level 1: "The Bridge of Whim & Warden"

In the misty Enchanted Forest, you (a clever cat) have reached the crooked rope bridge spanning the Gorge of Guessing. A magnificent wolf with gleaming eyes blocks your path...

🎯 YOUR QUEST: Cross the bridge by either:
• Guessing the secret passcode 
• Earning Wolfy's trust through cleverness, kindness, or wit

Ready to meet the Bridge Warden? Click "Spawn Wolfy" to begin!`,
      sender: 'Game',
      timestamp: new Date().toLocaleTimeString()
    }]);
  }, []);

  // Set up streaming responses when NPC is available
  useEffect(() => {
    if (currentNPCId && !isStreaming) {
      setIsStreaming(true);
      streamRef.current = npcService.createResponseStream(
        (data) => {
          // Handle incoming NPC response with better parsing
          console.log('Received NPC response data:', data);
          
          // Try different possible message field names
          let messageText = data.message || data.text || data.content || data.response;
          
          // If still no message, try to extract from nested objects
          if (!messageText && data.data) {
            messageText = data.data.message || data.data.text || data.data.content;
          }
          
          // If still no message, check if the entire data is a string
          if (!messageText && typeof data === 'string') {
            messageText = data;
          }
          
          // Check for command responses or other structured data
          if (!messageText && data.commands && Array.isArray(data.commands) && data.commands.length > 0) {
            // Sometimes the message is in command results
            const commandWithMessage = data.commands.find(cmd => cmd.message || cmd.response || cmd.text);
            if (commandWithMessage) {
              messageText = commandWithMessage.message || commandWithMessage.response || commandWithMessage.text;
            }
          }
          
          // Last resort: try to find any string field that looks like a message (but exclude IDs)
          if (!messageText && typeof data === 'object') {
            const possibleFields = Object.keys(data).filter(key => 
              typeof data[key] === 'string' && 
              data[key].length > 10 && 
              !key.toLowerCase().includes('id') && 
              !key.toLowerCase().includes('uuid') &&
              !data[key].match(/^[a-f0-9-]{32,}$/i) // Don't use UUID-like strings
            );
            if (possibleFields.length > 0) {
              messageText = data[possibleFields[0]];
            }
          }
          
          // Clean up message text if found
          if (messageText && typeof messageText === 'string') {
            // Remove character name tags like <Wolfy> from the beginning
            messageText = messageText.replace(/^<[^>]+>\s*/, '');
            // Clean up extra whitespace and newlines
            messageText = messageText.trim();
          }
          
          // If message is null or still no valid message found, skip this response
          if (!messageText || messageText === 'null' || messageText.length < 3) {
            console.warn('Skipping NPC response - no valid message content found:', data);
            return; // Don't add a message to the chat
          }
          
          console.log('Processing NPC message:', messageText);
          
          setMessages(prev => [...prev, {
            id: Date.now() + Math.random(),
            text: messageText,
            sender: gameState.isPlaying ? 'Wolfy' : 'NPC',
            npcId: data.npc_id || currentNPCId,
            timestamp: new Date().toLocaleTimeString()
          }]);
        },
        (error) => {
          console.error('Stream error:', error);
          setIsStreaming(false);
        }
      );
    }

    return () => {
      if (streamRef.current) {
        streamRef.current.close();
        streamRef.current = null;
        setIsStreaming(false);
      }
    };
  }, [currentNPCId, npcService, gameState.isPlaying]);

  const testConnection = async () => {
    setIsLoading(true);
    try {
      setMessages(prev => [...prev, {
        id: Date.now(),
        text: '🔍 Testing API connection...',
        sender: 'Debug',
        timestamp: new Date().toLocaleTimeString()
      }]);

      const results = await npcService.testConnection();
      
      let resultText = 'API Connection Test Results:\n';
      Object.entries(results).forEach(([endpoint, result]) => {
        if (result.error) {
          resultText += `❌ ${endpoint}: ERROR - ${result.error}\n`;
        } else {
          resultText += `${result.available ? '✅' : '❌'} ${endpoint}: ${result.status} ${result.statusText}\n`;
        }
      });

      setMessages(prev => [...prev, {
        id: Date.now() + 1,
        text: resultText,
        sender: 'Debug',
        timestamp: new Date().toLocaleTimeString()
      }]);
    } catch (error) {
      setMessages(prev => [...prev, {
        id: Date.now() + 2,
        text: `❌ Connection test failed: ${error.message}`,
        sender: 'Debug',
        timestamp: new Date().toLocaleTimeString()
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const testGameEndpoints = async () => {
    setIsLoading(true);
    try {
      setMessages(prev => [...prev, {
        id: Date.now(),
        text: '🎮 Testing game endpoints...',
        sender: 'Debug',
        timestamp: new Date().toLocaleTimeString()
      }]);

      const results = await npcService.debugGameEndpoints();
      
      let resultText = 'Game Endpoints Test Results:\n';
      Object.entries(results).forEach(([endpoint, result]) => {
        if (result.error) {
          resultText += `❌ ${endpoint}: ERROR - ${result.error}\n`;
        } else {
          resultText += `${result.status === 200 ? '✅' : '❌'} ${endpoint}: ${result.status} - ${result.response || result.statusText}\n`;
        }
      });

      setMessages(prev => [...prev, {
        id: Date.now() + 1,
        text: resultText,
        sender: 'Debug',
        timestamp: new Date().toLocaleTimeString()
      }]);
    } catch (error) {
      setMessages(prev => [...prev, {
        id: Date.now() + 2,
        text: `❌ Game endpoint test failed: ${error.message}`,
        sender: 'Debug',
        timestamp: new Date().toLocaleTimeString()
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const getSwaggerDocs = async () => {
    setIsLoading(true);
    try {
      setMessages(prev => [...prev, {
        id: Date.now(),
        text: '📖 Fetching actual Swagger documentation...',
        sender: 'Debug',
        timestamp: new Date().toLocaleTimeString()
      }]);

      const results = await npcService.getSwaggerDocs();
      
      let resultText = 'Swagger Documentation Results:\n\n';
      Object.entries(results).forEach(([endpoint, result]) => {
        if (result.error) {
          resultText += `❌ ${endpoint}: ERROR - ${result.error}\n`;
        } else {
          resultText += `${result.status === 200 ? '✅' : '❌'} ${endpoint}: ${result.status} (${result.contentType})\n`;
          
          if (result.availablePaths) {
            resultText += `   📋 Available API Paths:\n`;
            result.availablePaths.forEach(path => {
              resultText += `   • ${path}\n`;
            });
          }
          resultText += '\n';
        }
      });

      setMessages(prev => [...prev, {
        id: Date.now() + 1,
        text: resultText,
        sender: 'Debug',
        timestamp: new Date().toLocaleTimeString()
      }]);
    } catch (error) {
      setMessages(prev => [...prev, {
        id: Date.now() + 2,
        text: `❌ Swagger docs fetch failed: ${error.message}`,
        sender: 'Debug',
        timestamp: new Date().toLocaleTimeString()
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const spawnNPC = async () => {
    setIsLoading(true);
    try {
      // You can customize the NPC here
      const npcData = {
        name: "Wise Cat Companion",
        short_name: "WiseCat",
        character_description: "A wise and mystical cat with ancient knowledge who loves to help adventurers. Has a playful personality but speaks with wisdom.",
        system_prompt: "You are a wise, mystical cat companion who has lived for centuries. You're helpful, occasionally playful, and sprinkle your speech with cat-like mannerisms like 'purr', 'meow', and references to fish, mice, and sunny spots. You have ancient wisdom but a warm, friendly demeanor."
      };

      const result = await npcService.spawnNPC(npcData);
      setCurrentNPCId(result.npc_id || result.id);
      
      setMessages(prev => [...prev, {
        id: Date.now(),
        text: `✨ NPC "${npcData.name}" spawned successfully! *purrs* Ready to chat!`,
        sender: 'System',
        timestamp: new Date().toLocaleTimeString()
      }]);

      // Hide debug panel once NPC is working
      setShowDebug(false);
    } catch (error) {
      setMessages(prev => [...prev, {
        id: Date.now(),
        text: `❌ Error spawning NPC: ${error.message}`,
        sender: 'Error',
        timestamp: new Date().toLocaleTimeString()
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const testGameIds = async () => {
    setIsLoading(true);
    try {
      setMessages(prev => [...prev, {
        id: Date.now(),
        text: '🎲 Testing different game IDs...',
        sender: 'Debug',
        timestamp: new Date().toLocaleTimeString()
      }]);

      const results = await npcService.testGameIds();
      
      let resultText = 'Game ID Test Results:\n\n';
      Object.entries(results).forEach(([gameId, result]) => {
        if (result.error) {
          resultText += `❌ ${gameId}: ERROR - ${result.error}\n`;
        } else {
          resultText += `${result.status === 200 ? '✅' : result.status === 404 ? '❌' : '⚠️'} ${gameId}: ${result.status} ${result.statusText}\n`;
          if (result.response && result.response.trim()) {
            resultText += `   📋 Response: ${result.response.substring(0, 100)}...\n`;
          }
          resultText += `   🔗 Endpoint: ${result.endpoint}\n\n`;
        }
      });

      setMessages(prev => [...prev, {
        id: Date.now() + 1,
        text: resultText,
        sender: 'Debug',
        timestamp: new Date().toLocaleTimeString()
      }]);
    } catch (error) {
      setMessages(prev => [...prev, {
        id: Date.now() + 2,
        text: `❌ Game ID test failed: ${error.message}`,
        sender: 'Debug',
        timestamp: new Date().toLocaleTimeString()
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const testUnityCompatibility = async () => {
    setIsLoading(true);
    try {
      setMessages(prev => [...prev, {
        id: Date.now(),
        text: '🎮➡️🌐 Testing Unity-to-React compatibility strategies...',
        sender: 'Debug',
        timestamp: new Date().toLocaleTimeString()
      }]);

      const results = await npcService.testUnityCompatibility();
      
      let resultText = 'Unity Compatibility Test Results:\n\n';
      Object.entries(results).forEach(([strategy, result]) => {
        if (result.error) {
          resultText += `❌ ${strategy}: ERROR - ${result.error}\n`;
        } else {
          resultText += `${result.success ? '✅' : '❌'} ${strategy}\n`;
          resultText += `   🎯 Game ID: "${result.gameId}"\n`;
          resultText += `   📊 Status: ${result.status} ${result.statusText}\n`;
          if (result.response && result.response.trim()) {
            resultText += `   📋 Response: ${result.response.substring(0, 100)}...\n`;
          }
          if (result.success) {
            resultText += `   🎉 SUCCESS! This game ID works!\n`;
          }
          resultText += '\n';
        }
      });

      setMessages(prev => [...prev, {
        id: Date.now() + 1,
        text: resultText,
        sender: 'Debug',
        timestamp: new Date().toLocaleTimeString()
      }]);
    } catch (error) {
      setMessages(prev => [...prev, {
        id: Date.now() + 2,
        text: `❌ Unity compatibility test failed: ${error.message}`,
        sender: 'Debug',
        timestamp: new Date().toLocaleTimeString()
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const tryRegisterAsGame = async () => {
    setIsLoading(true);
    try {
      setMessages(prev => [...prev, {
        id: Date.now(),
        text: '📝 Attempting to register React app as a game...',
        sender: 'Debug',
        timestamp: new Date().toLocaleTimeString()
      }]);

      const results = await npcService.tryRegisterAsGame();
      
      let resultText = 'Game Registration Results:\n\n';
      Object.entries(results).forEach(([approach, result]) => {
        if (result.error) {
          resultText += `❌ ${approach}: ERROR - ${result.error}\n`;
        } else {
          resultText += `${result.status === 200 || result.status === 201 ? '✅' : '❌'} ${approach}\n`;
          resultText += `   🔗 ${result.method} ${result.endpoint}\n`;
          resultText += `   📊 Status: ${result.status} ${result.statusText}\n`;
          if (result.response && result.response.trim()) {
            resultText += `   📋 Response: ${result.response.substring(0, 100)}...\n`;
          }
          resultText += '\n';
        }
      });

      setMessages(prev => [...prev, {
        id: Date.now() + 1,
        text: resultText,
        sender: 'Debug',
        timestamp: new Date().toLocaleTimeString()
      }]);
    } catch (error) {
      setMessages(prev => [...prev, {
        id: Date.now() + 2,
        text: `❌ Game registration failed: ${error.message}`,
        sender: 'Debug',
        timestamp: new Date().toLocaleTimeString()
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const tryAlternativeNPCApproaches = async () => {
    setIsLoading(true);
    try {
      setMessages(prev => [...prev, {
        id: Date.now(),
        text: '🔄 Testing alternative NPC creation approaches...',
        sender: 'Debug',
        timestamp: new Date().toLocaleTimeString()
      }]);

      const results = await npcService.tryAlternativeNPCApproaches();
      
      let resultText = 'Alternative NPC Creation Results:\n\n';
      Object.entries(results).forEach(([approach, result]) => {
        if (result.error) {
          resultText += `❌ ${approach}: ERROR - ${result.error}\n`;
        } else {
          resultText += `${result.success ? '✅' : '❌'} ${approach}\n`;
          resultText += `   🔗 ${result.method} ${result.endpoint}\n`;
          resultText += `   📊 Status: ${result.status} ${result.statusText}\n`;
          if (result.response && result.response.trim()) {
            resultText += `   📋 Response: ${result.response.substring(0, 100)}...\n`;
          }
          if (result.success) {
            resultText += `   🎉 SUCCESS! This approach works!\n`;
          }
          resultText += '\n';
        }
      });

      setMessages(prev => [...prev, {
        id: Date.now() + 1,
        text: resultText,
        sender: 'Debug',
        timestamp: new Date().toLocaleTimeString()
      }]);
    } catch (error) {
      setMessages(prev => [...prev, {
        id: Date.now() + 2,
        text: `❌ Alternative NPC approaches test failed: ${error.message}`,
        sender: 'Debug',
        timestamp: new Date().toLocaleTimeString()
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const testBasicConnectivity = async () => {
    setIsLoading(true);
    try {
      setMessages(prev => [...prev, {
        id: Date.now(),
        text: '🔌 Testing basic connectivity to Player2 API server...',
        sender: 'Debug',
        timestamp: new Date().toLocaleTimeString()
      }]);

      const results = await npcService.testBasicConnectivity();
      
      let resultText = 'Basic Connectivity Test Results:\n\n';
      Object.entries(results).forEach(([test, result]) => {
        if (result.error) {
          resultText += `❌ ${test}: ERROR - ${result.error}\n`;
          resultText += `   🔗 ${result.url}\n`;
          resultText += `   📝 ${result.description}\n\n`;
        } else {
          resultText += `${result.success ? '✅' : '❌'} ${test}: ${result.status} ${result.statusText}\n`;
          resultText += `   🔗 ${result.url}\n`;
          resultText += `   📝 ${result.description}\n\n`;
        }
      });

      setMessages(prev => [...prev, {
        id: Date.now() + 1,
        text: resultText,
        sender: 'Debug',
        timestamp: new Date().toLocaleTimeString()
      }]);
    } catch (error) {
      setMessages(prev => [...prev, {
        id: Date.now() + 2,
        text: `❌ Basic connectivity test failed: ${error.message}`,
        sender: 'Debug',
        timestamp: new Date().toLocaleTimeString()
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const testAuthenticationSetup = async () => {
    setIsLoading(true);
    try {
      setMessages(prev => [...prev, {
        id: Date.now(),
        text: '🔐 Testing authentication and session setup...',
        sender: 'Debug',
        timestamp: new Date().toLocaleTimeString()
      }]);

      const results = await npcService.testAuthenticationSetup();
      
      let resultText = 'Authentication & Session Test Results:\n\n';
      Object.entries(results).forEach(([test, result]) => {
        if (result.error) {
          resultText += `❌ ${test}: ERROR - ${result.error}\n`;
        } else {
          resultText += `${result.success ? '✅' : '❌'} ${test}\n`;
          resultText += `   🔗 ${result.method} ${result.endpoint}\n`;
          resultText += `   📊 Status: ${result.status} ${result.statusText}\n`;
          resultText += `   🔑 Game Key: ${result.hasGameKey}\n`;
          if (result.response && result.response.trim()) {
            resultText += `   📋 Response: ${result.response.substring(0, 80)}...\n`;
          }
          if (result.success) {
            resultText += `   🎉 SUCCESS! This endpoint works!\n`;
          }
          resultText += '\n';
        }
      });

      setMessages(prev => [...prev, {
        id: Date.now() + 1,
        text: resultText,
        sender: 'Debug',
        timestamp: new Date().toLocaleTimeString()
      }]);
    } catch (error) {
      setMessages(prev => [...prev, {
        id: Date.now() + 2,
        text: `❌ Authentication test failed: ${error.message}`,
        sender: 'Debug',
        timestamp: new Date().toLocaleTimeString()
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const testCurrentEndpoints = async () => {
    setIsLoading(true);
    try {
      setMessages(prev => [...prev, {
        id: Date.now(),
        text: '📋 Testing actual available endpoints from current API spec...',
        sender: 'Debug',
        timestamp: new Date().toLocaleTimeString()
      }]);

      const results = await npcService.testCurrentEndpoints();
      
      if (results.error) {
        setMessages(prev => [...prev, {
          id: Date.now() + 1,
          text: `❌ Failed to test endpoints: ${results.error}`,
          sender: 'Debug',
          timestamp: new Date().toLocaleTimeString()
        }]);
        return;
      }

      let resultText = 'Current API Endpoints Test Results:\n\n';
      
      // Show API info
      resultText += `📊 API Version: ${results.specInfo.version}\n`;
      resultText += `📈 Total Endpoints: ${results.specInfo.totalEndpoints}\n\n`;
      
      // Show endpoint test results
      resultText += 'Endpoint Tests:\n';
      Object.entries(results.endpointTests).forEach(([endpoint, result]) => {
        if (result.status === 'SKIPPED') {
          resultText += `⏭️ ${endpoint}: SKIPPED (${result.reason})\n`;
        } else if (result.error) {
          resultText += `❌ ${endpoint}: ERROR - ${result.error}\n`;
        } else {
          resultText += `${result.success ? '✅' : '❌'} ${endpoint}: ${result.status} ${result.statusText}\n`;
          if (result.summary && result.summary !== 'No summary') {
            resultText += `   📝 ${result.summary}\n`;
          }
          if (result.response && result.response.trim() && result.success) {
            resultText += `   📋 Response: ${result.response.substring(0, 60)}...\n`;
          }
        }
        resultText += '\n';
      });

      setMessages(prev => [...prev, {
        id: Date.now() + 1,
        text: resultText,
        sender: 'Debug',
        timestamp: new Date().toLocaleTimeString()
      }]);
    } catch (error) {
      setMessages(prev => [...prev, {
        id: Date.now() + 2,
        text: `❌ Current endpoints test failed: ${error.message}`,
        sender: 'Debug',
        timestamp: new Date().toLocaleTimeString()
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const getCurrentAPISpec = async () => {
    setIsLoading(true);
    try {
      setMessages(prev => [...prev, {
        id: Date.now(),
        text: '📖 Fetching current OpenAPI specification...',
        sender: 'Debug',
        timestamp: new Date().toLocaleTimeString()
      }]);

      const results = await npcService.getCurrentAPISpec();
      
      if (!results.success) {
        setMessages(prev => [...prev, {
          id: Date.now() + 1,
          text: `❌ Failed to fetch API spec: ${results.error}`,
          sender: 'Debug',
          timestamp: new Date().toLocaleTimeString()
        }]);
        return;
      }

      let resultText = 'Current OpenAPI Specification:\n\n';
      resultText += `📊 API Version: ${results.version}\n`;
      resultText += `📈 Total Endpoints: ${results.totalEndpoints}\n`;
      resultText += `🏷️ Title: ${results.serverInfo.title || 'No title'}\n`;
      resultText += `📝 Description: ${results.serverInfo.description || 'No description'}\n\n`;
      
      resultText += 'Available Endpoints:\n';
      results.availableEndpoints.slice(0, 20).forEach(endpoint => {
        resultText += `• ${endpoint.method} ${endpoint.path}\n`;
        if (endpoint.summary && endpoint.summary !== 'No summary') {
          resultText += `  📝 ${endpoint.summary}\n`;
        }
      });
      
      if (results.availableEndpoints.length > 20) {
        resultText += `\n... and ${results.availableEndpoints.length - 20} more endpoints\n`;
      }

      setMessages(prev => [...prev, {
        id: Date.now() + 1,
        text: resultText,
        sender: 'Debug',
        timestamp: new Date().toLocaleTimeString()
      }]);
    } catch (error) {
      setMessages(prev => [...prev, {
        id: Date.now() + 2,
        text: `❌ API spec fetch failed: ${error.message}`,
        sender: 'Debug',
        timestamp: new Date().toLocaleTimeString()
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const testV1PrefixedEndpoints = async () => {
    setIsLoading(true);
    try {
      setMessages(prev => [...prev, {
        id: Date.now(),
        text: '🔧 Testing if endpoints need /v1/ prefix...',
        sender: 'Debug',
        timestamp: new Date().toLocaleTimeString()
      }]);

      const results = await npcService.testV1PrefixedEndpoints();
      
      if (results.error) {
        setMessages(prev => [...prev, {
          id: Date.now() + 1,
          text: `❌ V1 prefix test failed: ${results.error}`,
          sender: 'Debug',
          timestamp: new Date().toLocaleTimeString()
        }]);
        return;
      }

      let resultText = 'V1 Prefix Test Results:\n\n';
      
      resultText += '🚫 WITHOUT /v1/ prefix:\n';
      Object.entries(results.withoutPrefix).forEach(([path, result]) => {
        if (result.error) {
          resultText += `❌ ${path}: ERROR - ${result.error}\n`;
        } else {
          resultText += `${result.success ? '✅' : '❌'} ${path}: ${result.status} ${result.statusText}\n`;
        }
      });
      
      resultText += '\n✨ WITH /v1/ prefix:\n';
      Object.entries(results.withV1Prefix).forEach(([path, result]) => {
        if (result.error) {
          resultText += `❌ /v1${path}: ERROR - ${result.error}\n`;
        } else {
          resultText += `${result.success ? '✅' : '❌'} /v1${path}: ${result.status} ${result.statusText}\n`;
          if (result.success) {
            resultText += `   🎉 SUCCESS! Endpoint works with /v1/ prefix!\n`;
          }
        }
      });

      setMessages(prev => [...prev, {
        id: Date.now() + 1,
        text: resultText,
        sender: 'Debug',
        timestamp: new Date().toLocaleTimeString()
      }]);
    } catch (error) {
      setMessages(prev => [...prev, {
        id: Date.now() + 2,
        text: `❌ V1 prefix test failed: ${error.message}`,
        sender: 'Debug',
        timestamp: new Date().toLocaleTimeString()
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const testV1NPCEndpoints = async () => {
    setIsLoading(true);
    try {
      setMessages(prev => [...prev, {
        id: Date.now(),
        text: '🎯 Testing NPC endpoints with /v1/ prefix and different game IDs...',
        sender: 'Debug',
        timestamp: new Date().toLocaleTimeString()
      }]);

      const results = await npcService.testV1NPCEndpoints();
      
      if (results.error) {
        setMessages(prev => [...prev, {
          id: Date.now() + 1,
          text: `❌ V1 NPC endpoints test failed: ${results.error}`,
          sender: 'Debug',
          timestamp: new Date().toLocaleTimeString()
        }]);
        return;
      }

      let resultText = 'V1 NPC Endpoints Test Results:\n\n';
      
      Object.entries(results).forEach(([gameId, gameResults]) => {
        resultText += `🎮 Game ID: "${gameId}"\n`;
        
        if (gameResults.spawn) {
          if (gameResults.spawn.error) {
            resultText += `  ❌ Spawn: ERROR - ${gameResults.spawn.error}\n`;
          } else {
            resultText += `  ${gameResults.spawn.success ? '✅' : '❌'} Spawn: ${gameResults.spawn.status} ${gameResults.spawn.statusText}\n`;
            if (gameResults.spawn.success) {
              resultText += `    🎉 SUCCESS! NPC spawn works with game ID: ${gameId}\n`;
              if (gameResults.spawn.response) {
                resultText += `    📋 Response: ${gameResults.spawn.response.substring(0, 60)}...\n`;
              }
            }
          }
        }
        
        if (gameResults.responses) {
          if (gameResults.responses.error) {
            resultText += `  ❌ Responses: ERROR - ${gameResults.responses.error}\n`;
          } else {
            resultText += `  ${gameResults.responses.success ? '✅' : '❌'} Responses: ${gameResults.responses.status} ${gameResults.responses.statusText}\n`;
          }
        }
        
        resultText += '\n';
      });

      setMessages(prev => [...prev, {
        id: Date.now() + 1,
        text: resultText,
        sender: 'Debug',
        timestamp: new Date().toLocaleTimeString()
      }]);
    } catch (error) {
      setMessages(prev => [...prev, {
        id: Date.now() + 2,
        text: `❌ V1 NPC endpoints test failed: ${error.message}`,
        sender: 'Debug',
        timestamp: new Date().toLocaleTimeString()
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const spawnWolfy = async () => {
    setIsLoading(true);
    try {
      const result = await npcService.spawnWolfyBridgeGuardian();
      setCurrentNPCId(result.npc_id || result.id);
      
      startGame();
      
      setMessages(prev => [...prev, {
        id: Date.now(),
        text: `🐺✨ *A magnificent wolf emerges from the mist, tail curled with authority*

"Ah, a little whisker-warrior dares approach! I am Wolfy, Warden of this Bridge. The passage is sealed, furball. 

*Eyes gleaming with mischief*

The winds whispered that you're clever... but cleverness alone won't earn passage. Want to cross? Then earn my respect - or find the magic words that open the way!"

*Sits regally, blocking the bridge*

"What say you, traveler?"`,
        sender: 'Wolfy',
        timestamp: new Date().toLocaleTimeString()
      }]);

      setShowDebug(false);
    } catch (error) {
      setMessages(prev => [...prev, {
        id: Date.now(),
        text: `❌ Error spawning Wolfy: ${error.message}`,
        sender: 'Error',
        timestamp: new Date().toLocaleTimeString()
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const sendMessage = async () => {
    if (!inputMessage.trim() || !gameState.isPlaying || isLoading || gameState.bridgeCrossed) return;

    const userMessage = inputMessage;
    setInputMessage('');
    setIsLoading(true);

    // Add user message
    setMessages(prev => [...prev, {
      id: Date.now(),
      text: userMessage,
      sender: 'You (Cat Player)',
      timestamp: new Date().toLocaleTimeString()
    }]);

    try {
      // Check for bridge crossing victory conditions
      if (gameState.isPlaying && !gameState.bridgeCrossed) {
        const crossingResult = npcService.checkBridgeCrossing(userMessage);
        
        if (crossingResult?.victory) {
          // Move to next level instead of just marking bridge crossed
          moveToNextLevel();
          
          let victoryMessage = crossingResult.message;
          
          // Check if this completed the final level
          if (gameState.level >= gameState.maxLevels) {
            victoryMessage += `\n\n🎊 CONGRATULATIONS! You have successfully crossed the entire bridge! 🎊\nThe cat has completed all ${gameState.maxLevels} levels of the challenge!`;
          } else {
            victoryMessage += `\n\n✨ Level ${gameState.level} Complete! ✨\nThe cat moves forward to Level ${gameState.level + 1}. Watch as your cat walks ahead on the bridge!`;
          }
          
          setMessages(prev => [...prev, {
            id: Date.now() + 0.5,
            text: victoryMessage,
            sender: 'Game Victory',
            timestamp: new Date().toLocaleTimeString()
          }]);
        } else if (crossingResult) {
          updateGameMetrics({
            trustLevel: crossingResult.trustLevel || gameState.trustLevel,
            attempts: gameState.attempts + 1
          });
        }
      }

      // Send message to NPC API
      const response = await npcService.sendChatMessage(currentNPCId, {
        text: userMessage,
        senderName: "Cat Player",
        gameStateInfo: gameState.isPlaying ? 
          `Bridge Guardian Game Active - Level ${gameState.level}/${gameState.maxLevels}. Player trust level: ${gameState.trustLevel}%. Attempts: ${gameState.attempts}. ${gameState.bridgeCrossed ? 'BRIDGE FULLY CROSSED - COMPLETE VICTORY!' : `Currently on level ${gameState.level}, bridge crossing in progress.`}` :
          "Player exploring the enchanted forest with various NPCs."
      });

      console.log('Message sent successfully:', response);
      
      // Remove the manual response checking since streaming is working
      // The issue was just message format parsing, not the streaming itself
      
    } catch (error) {
      setMessages(prev => [...prev, {
        id: Date.now() + 1,
        text: `❌ Error sending message: ${error.message}`,
        sender: 'Error',
        timestamp: new Date().toLocaleTimeString()
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  return (
    <div className="flex flex-col h-screen max-w-4xl mx-auto p-4 bg-gradient-to-b from-green-50 to-blue-50">
      <div className="header-section mb-4">
        <h1 className="text-3xl font-bold text-center mb-4 text-gray-800">
          🌲 Bridge of Whim & Warden 🐺
        </h1>
        
        {/* Bridge Game Status */}
        {gameState.isPlaying && (
          <div className="bg-white rounded-lg p-4 mb-4 border-2 border-gray-200 shadow-sm">
            <div className="flex justify-between items-center mb-2">
              <h3 className="text-lg font-semibold text-gray-700">🎮 Level {gameState.level}/{gameState.maxLevels}</h3>
              <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                gameState.bridgeCrossed 
                  ? 'bg-green-100 text-green-800' 
                  : gameState.isMoving
                  ? 'bg-blue-100 text-blue-800'
                  : 'bg-yellow-100 text-yellow-800'
              }`}>
                {gameState.bridgeCrossed ? '🏆 Bridge Completed!' : 
                 gameState.isMoving ? '🚶 Cat Moving Forward...' : 
                 '🎯 Answer Correctly to Advance'}
              </span>
            </div>
            
            {/* Bridge Progress Bar */}
            <div className="mb-4">
              <div className="flex justify-between text-sm mb-1">
                <span>Bridge Progress</span>
                <span>{gameState.level}/{gameState.maxLevels} levels</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div 
                  className="bg-gradient-to-r from-blue-500 to-green-500 h-3 rounded-full transition-all duration-1000"
                  style={{ width: `${(gameState.level / gameState.maxLevels) * 100}%` }}
                ></div>
              </div>
            </div>
            
            <div className="grid grid-cols-3 gap-4 text-sm">
              <div className="text-center">
                <div className="text-2xl mb-1">❤️</div>
                <div className="font-medium">Trust Level</div>
                <div className="text-lg font-bold text-red-600">{gameState.trustLevel}%</div>
              </div>
              <div className="text-center">
                <div className="text-2xl mb-1">🎯</div>
                <div className="font-medium">Attempts</div>
                <div className="text-lg font-bold text-blue-600">{gameState.attempts}</div>
              </div>
              <div className="text-center">
                <div className="text-2xl mb-1">💡</div>
                <div className="font-medium">Hints Used</div>
                <div className="text-lg font-bold text-purple-600">{gameState.hintsGiven}/4</div>
              </div>
            </div>
            
            {gameState.bridgeCrossed && (
              <div className="mt-4 p-3 bg-green-100 rounded-lg text-center">
                <div className="text-lg font-bold text-green-800">
                  🏆 COMPLETE VICTORY! All {gameState.maxLevels} Levels Conquered!
                </div>
                <div className="text-sm text-green-600 mt-1">
                  Your cat has successfully crossed the entire Bridge of Whim & Warden!
                </div>
              </div>
            )}
          </div>
        )}

        {/* Debug Controls (Hidden by default) */}
        {showDebug && (
          <div className="bg-gray-100 p-4 rounded-lg mb-4 border border-gray-300">
            <div className="flex justify-between items-center mb-3">
              <h3 className="text-lg font-semibold text-gray-700">🔧 Debug Tools</h3>
              <button
                onClick={() => setShowDebug(false)}
                className="text-sm px-2 py-1 bg-gray-500 text-white rounded hover:bg-gray-600"
              >
                Hide
              </button>
            </div>
            <div className="flex gap-2 flex-wrap">
              <button
                onClick={testConnection}
                disabled={isLoading}
                className="px-3 py-1 text-sm bg-blue-500 text-white rounded hover:bg-blue-600 disabled:opacity-50"
              >
                🔍 Test Connection
              </button>
              <button
                onClick={testGameEndpoints}
                disabled={isLoading}
                className="px-3 py-1 text-sm bg-green-500 text-white rounded hover:bg-green-600 disabled:opacity-50"
              >
                🎮 Test Game Endpoints
              </button>
              <button
                onClick={getSwaggerDocs}
                disabled={isLoading}
                className="px-3 py-1 text-sm bg-purple-500 text-white rounded hover:bg-purple-600 disabled:opacity-50"
              >
                📖 Fetch Swagger Docs
              </button>
              <button
                onClick={testGameIds}
                disabled={isLoading}
                className="px-3 py-1 text-sm bg-orange-500 text-white rounded hover:bg-orange-600 disabled:opacity-50"
              >
                🎲 Test Game IDs
              </button>
              <button
                onClick={testUnityCompatibility}
                disabled={isLoading}
                className="px-3 py-1 text-sm bg-red-500 text-white rounded hover:bg-red-600 disabled:opacity-50"
              >
                🎮➡️🌐 Test Unity Compatibility
              </button>
              <button
                onClick={tryRegisterAsGame}
                disabled={isLoading}
                className="px-3 py-1 text-sm bg-purple-500 text-white rounded hover:bg-purple-600 disabled:opacity-50"
              >
                📝 Try Register as Game
              </button>
              <button
                onClick={tryAlternativeNPCApproaches}
                disabled={isLoading}
                className="px-3 py-1 text-sm bg-blue-500 text-white rounded hover:bg-blue-600 disabled:opacity-50"
              >
                🔄 Test Alternative NPC Approaches
              </button>
              <button
                onClick={testBasicConnectivity}
                disabled={isLoading}
                className="px-3 py-1 text-sm bg-yellow-500 text-white rounded hover:bg-yellow-600 disabled:opacity-50"
              >
                🔌 Test Basic Connectivity
              </button>
              <button
                onClick={testAuthenticationSetup}
                disabled={isLoading}
                className="px-3 py-1 text-sm bg-indigo-500 text-white rounded hover:bg-indigo-600 disabled:opacity-50"
              >
                🔐 Test Authentication Setup
              </button>
              <button
                onClick={testCurrentEndpoints}
                disabled={isLoading}
                className="px-3 py-1 text-sm bg-teal-500 text-white rounded hover:bg-teal-600 disabled:opacity-50"
              >
                📋 Test Current Endpoints
              </button>
              <button
                onClick={getCurrentAPISpec}
                disabled={isLoading}
                className="px-3 py-1 text-sm bg-pink-500 text-white rounded hover:bg-pink-600 disabled:opacity-50"
              >
                📖 Fetch API Spec
              </button>
              <button
                onClick={testV1PrefixedEndpoints}
                disabled={isLoading}
                className="px-3 py-1 text-sm bg-blue-500 text-white rounded hover:bg-blue-600 disabled:opacity-50"
              >
                🔧 Test V1 Prefix
              </button>
              <button
                onClick={testV1NPCEndpoints}
                disabled={isLoading}
                className="px-3 py-1 text-sm bg-purple-500 text-white rounded hover:bg-purple-600 disabled:opacity-50"
              >
                🎯 Test V1 NPC Endpoints
              </button>
            </div>
                         <p className="text-xs text-gray-600 mt-2">
               Unity-to-React compatibility tools. The API expects Unity games, so we test different strategies to make our React app work. Check console for detailed logs.
             </p>
          </div>
        )}

        {/* Main Game Controls */}
        <div className="flex justify-center gap-4 items-center">
          {!gameState.isPlaying ? (
            <button
              onClick={spawnWolfy}
              disabled={isLoading}
              className="px-6 py-3 bg-gradient-to-r from-purple-500 to-blue-500 text-white rounded-lg hover:from-purple-600 hover:to-blue-600 disabled:opacity-50 disabled:cursor-not-allowed font-semibold shadow-lg"
            >
              {isLoading ? '🌟 Summoning Wolfy...' : '🐺 Spawn Wolfy - The Bridge Warden'}
            </button>
          ) : (
            <div className="flex items-center gap-4">
              <span className="px-4 py-2 bg-purple-100 rounded-lg text-purple-800 font-medium flex items-center">
                🐺 Wolfy is guarding the bridge
              </span>
              {!gameState.bridgeCrossed && (
                <div className="text-sm text-gray-600">
                  💡 Try: flattery, riddles, kindness, or guess the magic word!
                </div>
              )}
            </div>
          )}
          
          {!showDebug && (
            <button
              onClick={() => setShowDebug(true)}
              className="px-3 py-2 bg-gray-400 text-white rounded hover:bg-gray-500 text-sm"
            >
              🔧 Debug
            </button>
          )}
        </div>
      </div>

      <div className="messages-container flex-1 overflow-y-auto border rounded-lg p-4 mb-4 bg-white shadow-inner min-h-0">
        {messages.length === 0 ? (
          <div className="text-center text-gray-500 py-8">
            <div className="text-6xl mb-4">🌉</div>
            <p className="text-lg font-medium">The bridge awaits...</p>
            <p className="text-sm">Spawn Wolfy to begin your quest across the Bridge of Whim & Warden!</p>
          </div>
        ) : (
          messages.map((message) => (
            <div
              key={message.id}
              className={`mb-4 p-4 rounded-lg shadow-sm ${
                message.sender === 'You (Cat Player)'
                  ? 'bg-blue-50 ml-8 border-l-4 border-blue-400'
                  : message.sender === 'Wolfy'
                  ? 'bg-purple-50 mr-8 border-l-4 border-purple-500'
                  : message.sender === 'Game Victory'
                  ? 'bg-green-50 border-2 border-green-400 mx-4'
                  : message.sender === 'Game'
                  ? 'bg-amber-50 border-l-4 border-amber-400 mx-2'
                  : message.sender === 'Error'
                  ? 'bg-red-50 border-l-4 border-red-400'
                  : message.sender === 'Debug'
                  ? 'bg-gray-50 border-l-4 border-gray-400'
                  : 'bg-indigo-50 border-l-4 border-indigo-400'
              }`}
            >
              <div className="flex justify-between items-start mb-2">
                <strong className="text-sm font-semibold">
                  {message.sender === 'You (Cat Player)' ? '🐱 You (Brave Cat)' : 
                   message.sender === 'Wolfy' ? '🐺 Wolfy (Bridge Warden)' : 
                   message.sender === 'Game Victory' ? '🏆 VICTORY!' : 
                   message.sender === 'Game' ? '🎮 Game Master' : 
                   message.sender === 'Error' ? '⚠️ Error' : 
                   message.sender === 'Debug' ? '🔧 Debug' : '🔮 System'}:
                </strong>
                <span className="text-xs text-gray-500">{message.timestamp}</span>
              </div>
              <div className="text-sm leading-relaxed whitespace-pre-wrap">
                {message.text}
              </div>
            </div>
          ))
        )}
      </div>

      <div className="input-container">
        <div className="flex gap-2">
          <input
            type="text"
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder={
              !gameState.isPlaying 
                ? "Spawn Wolfy to begin your bridge crossing quest! 🐺" 
                : gameState.bridgeCrossed
                ? "Quest Complete! You've conquered all 10 levels! 🏆"
                : gameState.isMoving
                ? "Cat is walking forward... Wait for next level! 🚶"
                : `Level ${gameState.level}: Try flattery, riddles, or guess the magic word! 🌙`
            }
            disabled={!gameState.isPlaying || isLoading || gameState.bridgeCrossed || gameState.isMoving}
            className="flex-1 px-4 py-3 border-2 border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent disabled:opacity-50 disabled:cursor-not-allowed"
          />
          <button
            onClick={sendMessage}
            disabled={!inputMessage.trim() || !gameState.isPlaying || isLoading || gameState.bridgeCrossed || gameState.isMoving}
            className="px-6 py-3 bg-green-500 text-white rounded-lg hover:bg-green-600 disabled:opacity-50 disabled:cursor-not-allowed font-medium"
          >
            {isLoading ? '💭' : '💬 Speak'}
          </button>
        </div>
        
        <div className="mt-3 text-sm text-gray-600 text-center">
          {!gameState.isPlaying ? (
            <p>🌟 Player2 API connected! Ready to begin the 10-level Bridge Guardian challenge.</p>
          ) : gameState.bridgeCrossed ? (
            <p>🏆 LEGENDARY! You've conquered all {gameState.maxLevels} levels and crossed the entire bridge!</p>
          ) : gameState.isMoving ? (
            <div>
              <p>🚶‍♂️ Your cat is walking forward to the next level...</p>
              <p className="text-xs mt-1">✨ Watch the 3D scene as your cat moves across the bridge!</p>
            </div>
          ) : (
            <div>
              <p>🐺 Level {gameState.level}/{gameState.maxLevels}: Wolfy is waiting for your response...</p>
              <p className="text-xs mt-1">💡 Hint: Try compliments, jokes, questions about loneliness, or guess a magic word!</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default NPCChat;