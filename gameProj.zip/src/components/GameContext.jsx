import React, { createContext, useContext, useState, useCallback } from 'react';

const GameContext = createContext();

export const useGame = () => {
  const context = useContext(GameContext);
  if (!context) {
    throw new Error('useGame must be used within a GameProvider');
  }
  return context;
};

export const GameProvider = ({ children }) => {
  const [gameState, setGameState] = useState({
    level: 1,
    maxLevels: 10,
    catPosition: [3, 1.1, -0.9], // Starting position from CatModel
    isMoving: false,
    bridgeCrossed: false,
    isPlaying: false,
    victoryType: null,
    trustLevel: 0,
    hintsGiven: 0,
    attempts: 0
  });

  // Calculate how far the cat should move forward per level
  // Total bridge distance divided by levels (from starting position to end)
  const BRIDGE_LENGTH = 8; // Total distance to cross the bridge
  const STEP_SIZE = BRIDGE_LENGTH / 10; // Distance per level

  const moveToNextLevel = useCallback(() => {
    setGameState(prev => {
      const newLevel = Math.min(prev.level + 1, prev.maxLevels);
      const newX = prev.catPosition[0] - (STEP_SIZE); // Move forward (negative X direction)
      
      return {
        ...prev,
        level: newLevel,
        catPosition: [newX, prev.catPosition[1], prev.catPosition[2]],
        isMoving: true,
        bridgeCrossed: newLevel >= prev.maxLevels,
        attempts: 0, // Reset attempts for new level
        trustLevel: 0 // Reset trust for new level
      };
    });

    // Stop moving animation after a delay
    setTimeout(() => {
      setGameState(prev => ({ ...prev, isMoving: false }));
    }, 2000); // 2 seconds of walking animation
  }, []);

  const startGame = useCallback(() => {
    setGameState(prev => ({ ...prev, isPlaying: true }));
  }, []);

  const updateGameMetrics = useCallback((updates) => {
    setGameState(prev => ({ ...prev, ...updates }));
  }, []);

  const resetGame = useCallback(() => {
    setGameState({
      level: 1,
      maxLevels: 10,
      catPosition: [3, 1.1, -0.9],
      isMoving: false,
      bridgeCrossed: false,
      isPlaying: false,
      victoryType: null,
      trustLevel: 0,
      hintsGiven: 0,
      attempts: 0
    });
  }, []);

  const value = {
    gameState,
    moveToNextLevel,
    startGame,
    updateGameMetrics,
    resetGame
  };

  return (
    <GameContext.Provider value={value}>
      {children}
    </GameContext.Provider>
  );
};