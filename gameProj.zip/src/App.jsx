import ThreeScene from './components/ThreeScene'
import NPCChat from './components/NPCChat'
import { GameProvider } from './components/GameContext'

function App() {
  return (
    <GameProvider>
      <div className="w-full h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex">
        {/* Main 3D Scene */}
        <div className="flex-1">
          <ThreeScene />
        </div>

        {/* NPC Chat Panel */}
        <div className="w-96 h-full overflow-hidden">
          <NPCChat />
        </div>
      </div>
    </GameProvider>
  )
}

export default App
