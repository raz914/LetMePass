const API_BASE_URL = '/api';

class NPCApiService {
  constructor(gameKey = 'let-me-pass') {
    this.gameKey = gameKey;
    this.gameId = 'let-me-pass'; // We confirmed this works with v1 prefix
  }

  // Common headers for all requests
  getHeaders() {
    return {
      'Content-Type': 'application/json',
      'player2-game-key': this.gameKey,
    };
  }

  // Try different game ID strategies for Unity-to-React compatibility
  async testUnityCompatibility() {
    try {
      console.log('Testing Unity-to-React compatibility...');
      
      // Different strategies to try
      const strategies = [
        { name: 'Use game key as game ID', gameId: this.gameKey },
        { name: 'Use game key (URL encoded)', gameId: encodeURIComponent(this.gameKey) },
        { name: 'Use game key (lowercase)', gameId: this.gameKey.toLowerCase().replace(/\s+/g, '') },
        { name: 'Use current game ID', gameId: this.gameId },
        { name: 'Use "web" as platform identifier', gameId: 'web' },
        { name: 'Use "react" as platform identifier', gameId: 'react' },
        { name: 'Use "browser" as platform identifier', gameId: 'browser' },
        { name: 'Use "default" game ID', gameId: 'default' },
      ];

      const results = {};
      
      for (const strategy of strategies) {
        try {
          console.log(`Testing strategy: ${strategy.name} (gameId: "${strategy.gameId}")`);
          
          // Test the spawn endpoint with this game ID
          const response = await fetch(`${API_BASE_URL}/npc/games/${strategy.gameId}/npcs/spawn`, {
            method: 'POST',
            headers: this.getHeaders(),
            body: JSON.stringify({
              character_description: "Test NPC for React app compatibility",
              commands: [],
              name: "Test NPC",
              short_name: "Test",
              system_prompt: "You are a test NPC to verify React app compatibility with Unity API.",
              voice_id: "test"
            }),
          });
          
          let responseText = '';
          try {
            responseText = await response.text();
          } catch (textError) {
            responseText = 'Could not read response text';
          }
          
          results[strategy.name] = {
            gameId: strategy.gameId,
            status: response.status,
            statusText: response.statusText,
            success: response.status >= 200 && response.status < 300,
            response: responseText.substring(0, 300)
          };
          
          console.log(`${strategy.name}: ${response.status} ${response.statusText}`);
          if (response.status >= 200 && response.status < 300) {
            console.log(`✅ SUCCESS! Working game ID: "${strategy.gameId}"`);
            // Update our game ID to the working one
            this.gameId = strategy.gameId;
            break; // Stop testing once we find a working one
          }
          
        } catch (error) {
          results[strategy.name] = {
            gameId: strategy.gameId,
            error: error.message
          };
          console.log(`${strategy.name}: ERROR - ${error.message}`);
        }
      }
      
      return results;
    } catch (error) {
      console.error('Unity compatibility test failed:', error);
      return { error: error.message };
    }
  }

  // Try to register our React app as a "game" 
  async tryRegisterAsGame() {
    try {
      console.log('Attempting to register React app as a game...');
      
      const gameRegistrations = [
        {
          name: 'Register with game key',
          method: 'PUT',
          endpoint: `/npc/games/${this.gameKey}`,
          body: { name: 'React NPC Chat App', platform: 'web' }
        },
        {
          name: 'Register at games endpoint',
          method: 'POST', 
          endpoint: '/npc/games',
          body: { id: this.gameKey, name: 'React NPC Chat App', platform: 'web' }
        },
        {
          name: 'Register at base games',
          method: 'POST',
          endpoint: '/games',
          body: { id: this.gameKey, name: 'React NPC Chat App', type: 'web' }
        }
      ];

      const results = {};

      for (const registration of gameRegistrations) {
        try {
          console.log(`Trying: ${registration.name}`);
          
          const response = await fetch(`${API_BASE_URL}${registration.endpoint}`, {
            method: registration.method,
            headers: this.getHeaders(),
            body: JSON.stringify(registration.body),
          });
          
          let responseText = '';
          try {
            responseText = await response.text();
          } catch (textError) {
            responseText = 'Could not read response text';
          }
          
          results[registration.name] = {
            method: registration.method,
            endpoint: registration.endpoint,
            status: response.status,
            statusText: response.statusText,
            response: responseText.substring(0, 200)
          };
          
          console.log(`${registration.name}: ${response.status} ${response.statusText}`);
          
        } catch (error) {
          results[registration.name] = {
            method: registration.method,
            endpoint: registration.endpoint,
            error: error.message
          };
          console.log(`${registration.name}: ERROR - ${error.message}`);
        }
      }
      
      return results;
    } catch (error) {
      console.error('Game registration failed:', error);
      return { error: error.message };
    }
  }

  // Try alternative NPC creation approaches
  async tryAlternativeNPCApproaches() {
    try {
      console.log('Testing alternative NPC creation approaches...');
      
      const npcData = {
        character_description: "Test NPC for React app",
        commands: [],
        name: "Test NPC",
        short_name: "Test",
        system_prompt: "You are a test NPC.",
        voice_id: "test"
      };

      const approaches = [
        {
          name: 'Direct NPC spawn (no game path)',
          method: 'POST',
          endpoint: '/npc/spawn',
          body: npcData
        },
        {
          name: 'NPC spawn with game key in body',
          method: 'POST',
          endpoint: '/npc/spawn',
          body: { ...npcData, game_id: this.gameKey }
        },
        {
          name: 'Chat completions endpoint',
          method: 'POST',
          endpoint: '/chat/completions',
          body: {
            model: 'npc',
            messages: [{ role: 'user', content: 'Hello' }],
            game_id: this.gameKey
          }
        },
        {
          name: 'Selected characters endpoint',
          method: 'GET',
          endpoint: '/selected_characters'
        }
      ];

      const results = {};

      for (const approach of approaches) {
        try {
          console.log(`Testing: ${approach.name}`);
          
          const requestOptions = {
            method: approach.method,
            headers: this.getHeaders(),
          };

          if (approach.body && approach.method !== 'GET') {
            requestOptions.body = JSON.stringify(approach.body);
          }
          
          const response = await fetch(`${API_BASE_URL}${approach.endpoint}`, requestOptions);
          
          let responseText = '';
          try {
            responseText = await response.text();
          } catch (textError) {
            responseText = 'Could not read response text';
          }
          
          results[approach.name] = {
            method: approach.method,
            endpoint: approach.endpoint,
            status: response.status,
            statusText: response.statusText,
            success: response.status >= 200 && response.status < 300,
            response: responseText.substring(0, 300)
          };
          
          console.log(`${approach.name}: ${response.status} ${response.statusText}`);
          
        } catch (error) {
          results[approach.name] = {
            method: approach.method,
            endpoint: approach.endpoint,
            error: error.message
          };
          console.log(`${approach.name}: ERROR - ${error.message}`);
        }
      }
      
      return results;
    } catch (error) {
      console.error('Alternative NPC approaches test failed:', error);
      return { error: error.message };
    }
  }

  // Debug: Test basic API connectivity
  async testConnection() {
    try {
      console.log('Testing API connection...');
      
      // Test different endpoints to see what's available
      const endpoints = [
        '/',
        '/health',  // We know this exists!
        '/v1',
        '/docs',
        '/npc',
        `/npc/games`,
        `/npc/games/${this.gameId}`,
        `/npc/games/${this.gameId}/npcs`
      ];

      const results = {};
      
      for (const endpoint of endpoints) {
        try {
          const response = await fetch(`${API_BASE_URL}${endpoint}`, {
            method: 'GET',
            headers: this.getHeaders(),
          });
          
          let responseText = '';
          try {
            responseText = await response.text();
          } catch (textError) {
            responseText = 'Could not read response text';
          }
          
          results[endpoint] = {
            status: response.status,
            statusText: response.statusText,
            available: response.status !== 404,
            response: responseText.substring(0, 200) // First 200 chars
          };
          
          console.log(`${endpoint}: ${response.status} ${response.statusText}`);
          if (responseText && responseText.length > 0) {
            console.log(`  Response: ${responseText.substring(0, 100)}...`);
          }
        } catch (error) {
          results[endpoint] = {
            status: 'ERROR',
            statusText: error.message,
            available: false
          };
          console.log(`${endpoint}: ERROR - ${error.message}`);
        }
      }
      
      return results;
    } catch (error) {
      console.error('Connection test failed:', error);
      return { error: error.message };
    }
  }

  // Debug: Test different game IDs
  async testGameIds() {
    try {
      console.log('Testing different game IDs...');
      
      // Try different possible game IDs
      const gameIds = [
        'Loki1212',     // Current one
        'default',      // Maybe there's a default game
        'test',         // Common test game
        'game1',        // Simple ID
        '',             // Empty - maybe we don't need one
      ];

      const results = {};
      
      for (const gameId of gameIds) {
        const gameIdPath = gameId ? gameId : '[empty]';
        const endpoint = gameId ? `/npc/games/${gameId}` : '/npc/games';
        
        try {
          const response = await fetch(`${API_BASE_URL}${endpoint}`, {
            method: 'GET',
            headers: this.getHeaders(),
          });
          
          let responseText = '';
          try {
            responseText = await response.text();
          } catch (textError) {
            responseText = 'Could not read response text';
          }
          
          results[gameIdPath] = {
            status: response.status,
            statusText: response.statusText,
            endpoint: endpoint,
            response: responseText.substring(0, 200)
          };
          
          console.log(`Game ID "${gameIdPath}": ${response.status} ${response.statusText}`);
          if (responseText && responseText.length > 0) {
            console.log(`  Response: ${responseText.substring(0, 100)}...`);
          }
        } catch (error) {
          results[gameIdPath] = {
            error: error.message,
            endpoint: endpoint
          };
          console.log(`Game ID "${gameIdPath}": ERROR - ${error.message}`);
        }
      }
      
      return results;
    } catch (error) {
      console.error('Game ID test failed:', error);
      return { error: error.message };
    }
  }

  // Debug: Try to list games or get game info
  async debugGameEndpoints() {
    try {
      console.log('Testing game-related endpoints...');
      
      const gameEndpoints = [
        '/games',
        '/v1/games',
        `/games/${this.gameId}`,
        `/v1/games/${this.gameId}`,
        '/npc/games',
        `/npc/games/${this.gameId}/info`
      ];

      const results = {};
      
      for (const endpoint of gameEndpoints) {
        try {
          const response = await fetch(`${API_BASE_URL}${endpoint}`, {
            method: 'GET',
            headers: this.getHeaders(),
          });
          
          const text = await response.text();
          results[endpoint] = {
            status: response.status,
            statusText: response.statusText,
            response: text.substring(0, 200) // First 200 chars
          };
          
          console.log(`${endpoint}: ${response.status} - ${text.substring(0, 100)}`);
        } catch (error) {
          results[endpoint] = { error: error.message };
        }
      }
      
      return results;
    } catch (error) {
      console.error('Game endpoints test failed:', error);
      return { error: error.message };
    }
  }

  // Debug: Fetch actual Swagger documentation
  async getSwaggerDocs() {
    try {
      console.log('Fetching Swagger documentation...');
      
      // Try different swagger/openapi endpoints
      const swaggerEndpoints = [
        '/docs',
        '/openapi.json',
        '/v1/openapi.json',
        '/swagger.json',
        '/api-docs'
      ];

      const results = {};
      
      for (const endpoint of swaggerEndpoints) {
        try {
          const response = await fetch(`${API_BASE_URL}${endpoint}`, {
            method: 'GET',
            headers: {
              'Accept': 'application/json, text/html, */*'
            },
          });
          
          const text = await response.text();
          results[endpoint] = {
            status: response.status,
            statusText: response.statusText,
            contentType: response.headers.get('content-type'),
            response: text
          };
          
          console.log(`${endpoint}: ${response.status} - Content-Type: ${response.headers.get('content-type')}`);
          
          // If we get JSON, try to parse it
          if (response.headers.get('content-type')?.includes('application/json')) {
            try {
              const json = JSON.parse(text);
              if (json.paths) {
                console.log('Available API paths:', Object.keys(json.paths));
                results[endpoint].availablePaths = Object.keys(json.paths);
              }
            } catch (parseError) {
              console.log('Could not parse JSON response');
            }
          }
          
        } catch (error) {
          results[endpoint] = { error: error.message };
        }
      }
      
      return results;
    } catch (error) {
      console.error('Swagger docs fetch failed:', error);
      return { error: error.message };
    }
  }

  // Create/spawn a new NPC - Updated to use v1 prefix
  async spawnNPC(npcData = {}) {
    try {
      // Default NPC data matching the API schema
      const defaultNPCData = {
        character_description: npcData.character_description || "A friendly and helpful AI companion who loves to chat and assist players in their adventures.",
        commands: npcData.commands || [
          {
            name: "weather_modifier",
            description: "takes in a value, and modifies the weather by that many degrees celsius",
            parameters: {
              type: "object",
              properties: {
                degrees: {
                  type: "integer",
                  description: "The number of degrees to modify the weather by, can be negative or positive"
                }
              },
              required: ["degrees"]
            }
          }
        ],
        name: npcData.name || "Friendly Cat Assistant",
        short_name: npcData.short_name || "Cat",
        system_prompt: npcData.system_prompt || "You are a helpful and friendly cat character who assists players in their journey. Be warm, encouraging, and occasionally make cat-like references in your speech.",
        voice_id: npcData.voice_id || "test"
      };

      console.log('Attempting to spawn NPC with data:', defaultNPCData);
      console.log('Full URL:', `${API_BASE_URL}/v1/npc/games/${this.gameId}/npcs/spawn`);

      const response = await fetch(`${API_BASE_URL}/v1/npc/games/${this.gameId}/npcs/spawn`, {
        method: 'POST',
        headers: this.getHeaders(),
        body: JSON.stringify(defaultNPCData),
      });
      
      const responseText = await response.text();
      console.log('Spawn response:', response.status, responseText);
      
      if (!response.ok) {
        throw new Error(`Failed to spawn NPC: ${response.status} ${response.statusText} - ${responseText}`);
      }
      
      // Handle both JSON and plain text responses
      let result;
      try {
        // Try parsing as JSON first
        result = JSON.parse(responseText);
      } catch (parseError) {
        // If not JSON, treat as plain text NPC ID
        console.log('Response is plain text, treating as NPC ID:', responseText);
        result = {
          npc_id: responseText.trim(),
          id: responseText.trim(),
          message: 'NPC spawned successfully'
        };
      }
      
      return result;
    } catch (error) {
      console.error('Error spawning NPC:', error);
      throw error;
    }
  }

  // Send chat message to specific NPC - Updated to use v1 prefix
  async sendChatMessage(npcId, message) {
    try {
      const chatData = {
        game_state_info: message.gameStateInfo || "The weather is currently 25°C. The player is in a peaceful 3D environment with various animated characters.",
        sender_message: message.text,
        sender_name: message.senderName || "Player"
      };

      const response = await fetch(`${API_BASE_URL}/v1/npc/games/${this.gameId}/npcs/${npcId}/chat`, {
        method: 'POST',
        headers: this.getHeaders(),
        body: JSON.stringify(chatData),
      });
      
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Failed to send chat message: ${response.status} ${response.statusText} - ${errorText}`);
      }
      
      // Handle both JSON and plain text/empty responses
      let result;
      try {
        const responseText = await response.text();
        console.log('Chat response:', response.status, responseText);
        
        if (responseText.trim()) {
          // Try parsing as JSON if there's content
          result = JSON.parse(responseText);
        } else {
          // Empty response is success for chat messages
          result = {
            success: true,
            message: 'Message sent successfully'
          };
        }
      } catch (parseError) {
        // If not JSON, treat as success (chat messages often don't return JSON)
        console.log('Chat response is not JSON, treating as success');
        result = {
          success: true,
          message: 'Message sent successfully'
        };
      }
      
      return result;
    } catch (error) {
      console.error('Error sending chat message:', error);
      throw error;
    }
  }

  // Helper function to extract message from various response formats
  extractMessageFromResponse(data) {
    if (!data) return null;
    
    // Direct message fields
    let messageText = null;
    
    if (data.message && typeof data.message === 'string' && data.message.trim()) {
      messageText = data.message.trim();
    } else if (data.text && typeof data.text === 'string' && data.text.trim()) {
      messageText = data.text.trim();
    } else if (data.content && typeof data.content === 'string' && data.content.trim()) {
      messageText = data.content.trim();
    } else if (data.response && typeof data.response === 'string' && data.response.trim()) {
      messageText = data.response.trim();
    }
    
    // Check in nested data
    if (!messageText && data.data && typeof data.data === 'object') {
      messageText = this.extractMessageFromResponse(data.data);
    }
    
    // Check in commands array
    if (!messageText && data.commands && Array.isArray(data.commands)) {
      for (const command of data.commands) {
        const commandMessage = this.extractMessageFromResponse(command);
        if (commandMessage) {
          messageText = commandMessage;
          break;
        }
      }
    }
    
    // Check for any field that looks like dialogue/message content
    if (!messageText && typeof data === 'object') {
      for (const [key, value] of Object.entries(data)) {
        if (typeof value === 'string' && 
            value.length > 10 && 
            !key.toLowerCase().includes('id') &&
            !key.toLowerCase().includes('uuid') &&
            !value.match(/^[a-f0-9-]{32,}$/i) &&
            (key.toLowerCase().includes('message') || 
             key.toLowerCase().includes('text') ||
             key.toLowerCase().includes('content') ||
             key.toLowerCase().includes('response') ||
             key.toLowerCase().includes('dialogue'))) {
          messageText = value.trim();
          break;
        }
      }
    }
    
    // Clean up message text if found
    if (messageText && typeof messageText === 'string') {
      // Remove character name tags like <Wolfy> from the beginning
      messageText = messageText.replace(/^<[^>]+>\s*/, '');
      // Clean up extra whitespace and newlines
      messageText = messageText.trim();
      
      // If after cleaning there's nothing left, return null
      if (messageText.length < 3) {
        return null;
      }
    }
    
    return messageText;
  }

  // Enhanced get responses with better parsing
  async getResponses() {
    try {
      const response = await fetch(`${API_BASE_URL}/v1/npc/games/${this.gameId}/npcs/responses`, {
        method: 'GET',
        headers: {
          ...this.getHeaders(),
          'Accept': 'application/x-json-stream'
        },
      });
      
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Failed to get responses: ${response.status} ${response.statusText} - ${errorText}`);
      }
      
      return response;
    } catch (error) {
      console.error('Error getting responses:', error);
      throw error;
    }
  }

  // Set up event source for streaming responses - Updated to use v1 prefix
  createResponseStream(onMessage, onError) {
    try {
      // Note: EventSource may not work with custom headers, so we'll use fetch with streaming
      this.startStreamingResponses(onMessage, onError);
      return { close: () => this.stopStreaming = true };
    } catch (error) {
      console.error('Failed to create response stream:', error);
      if (onError) onError(error);
      return null;
    }
  }

  // Alternative streaming method using fetch - Updated to use v1 prefix
  async startStreamingResponses(onMessage, onError) {
    this.stopStreaming = false;
    
    while (!this.stopStreaming) {
      try {
        const response = await fetch(`${API_BASE_URL}/v1/npc/games/${this.gameId}/npcs/responses`, {
          method: 'GET',
          headers: {
            ...this.getHeaders(),
            'Accept': 'application/x-json-stream'
          },
        });

        if (!response.ok) {
          throw new Error(`Streaming failed: ${response.status}`);
        }

        const reader = response.body.getReader();
        const decoder = new TextDecoder();

        while (!this.stopStreaming) {
          const { done, value } = await reader.read();
          
          if (done) break;
          
          const chunk = decoder.decode(value);
          const lines = chunk.split('\n').filter(line => line.trim());
          
          for (const line of lines) {
            try {
              // Try to parse as JSON
              const data = JSON.parse(line);
              console.log('Parsed NPC response:', data);
              
              // Check if this response actually contains a message
              const hasValidMessage = data.message && 
                                    data.message !== null && 
                                    typeof data.message === 'string' && 
                                    data.message.trim().length > 0;
              
              // Check if this looks like a text response (even if not in message field)
              const hasTextContent = data.text && 
                                    data.text !== null && 
                                    typeof data.text === 'string' && 
                                    data.text.trim().length > 0;
              
              // Check commands array for message content
              const hasCommandMessage = data.commands && 
                                      Array.isArray(data.commands) && 
                                      data.commands.some(cmd => 
                                        (cmd.message && cmd.message.trim()) ||
                                        (cmd.response && cmd.response.trim()) ||
                                        (cmd.text && cmd.text.trim())
                                      );
              
              // Only send responses that actually have message content
              if (hasValidMessage || hasTextContent || hasCommandMessage) {
                onMessage(data);
              } else {
                console.log('Skipping empty/metadata response:', data);
              }
              
            } catch (parseError) {
              console.log('Non-JSON line received:', line);
              
              // Check if it's a plain text response that looks like a message
              if (line.trim().length > 10 && !line.includes('HTTP') && !line.includes('error')) {
                console.log('Treating non-JSON line as text message:', line);
                onMessage({ message: line.trim(), text: line.trim() });
              }
            }
          }
        }
      } catch (error) {
        console.error('Streaming error:', error);
        if (onError) onError(error);
        // Wait before retrying
        await new Promise(resolve => setTimeout(resolve, 5000));
      }
    }
  }

  // Simple connectivity test to verify Player2 API server status
  async testBasicConnectivity() {
    try {
      console.log('Testing basic connectivity to Player2 API...');
      
      const tests = [
        {
          name: 'Direct IP test',
          url: 'http://127.0.0.1:4315',
          description: 'Test direct connection to Player2 API'
        },
        {
          name: 'Direct IP /docs',
          url: 'http://127.0.0.1:4315/docs',
          description: 'Test docs endpoint directly'
        },
        {
          name: 'Direct IP /health',
          url: 'http://127.0.0.1:4315/health',
          description: 'Test health endpoint directly'
        },
        {
          name: 'Proxy test',
          url: `${API_BASE_URL}/docs`,
          description: 'Test through our proxy'
        }
      ];

      const results = {};

      for (const test of tests) {
        try {
          console.log(`Testing: ${test.name}`);
          
          const response = await fetch(test.url, {
            method: 'GET',
            headers: {
              'Accept': 'text/html,application/json,*/*'
            }
          });
          
          results[test.name] = {
            url: test.url,
            status: response.status,
            statusText: response.statusText,
            success: response.status === 200,
            description: test.description
          };
          
          console.log(`${test.name}: ${response.status} ${response.statusText}`);
          
        } catch (error) {
          results[test.name] = {
            url: test.url,
            error: error.message,
            description: test.description,
            success: false
          };
          console.log(`${test.name}: ERROR - ${error.message}`);
        }
      }
      
      return results;
    } catch (error) {
      console.error('Basic connectivity test failed:', error);
      return { error: error.message };
    }
  }

  // Test authentication and session setup
  async testAuthenticationSetup() {
    try {
      console.log('Testing authentication and session setup...');
      
      const authTests = [
        {
          name: 'Check current session',
          method: 'GET',
          endpoint: '/docs',
          headers: this.getHeaders(),
          description: 'Test if we can access docs through proxy'
        },
        {
          name: 'Try v1 OpenAPI docs',
          method: 'GET', 
          endpoint: '/v1/openapi.json',
          headers: this.getHeaders(),
          description: 'Access OpenAPI spec that worked before'
        },
        {
          name: 'Test selected characters',
          method: 'GET',
          endpoint: '/selected_characters', 
          headers: this.getHeaders(),
          description: 'Check if we can access character endpoint'
        },
        {
          name: 'Test TTS voices',
          method: 'GET',
          endpoint: '/tts/voices',
          headers: this.getHeaders(), 
          description: 'Check TTS endpoint that should be available'
        },
        {
          name: 'Test without game key header',
          method: 'GET',
          endpoint: '/selected_characters',
          headers: { 'Content-Type': 'application/json' },
          description: 'Test if game key header is required'
        }
      ];

      const results = {};

      for (const test of authTests) {
        try {
          console.log(`Testing: ${test.name}`);
          
          const response = await fetch(`${API_BASE_URL}${test.endpoint}`, {
            method: test.method,
            headers: test.headers
          });
          
          let responseText = '';
          try {
            responseText = await response.text();
          } catch (textError) {
            responseText = 'Could not read response text';
          }
          
          results[test.name] = {
            method: test.method,
            endpoint: test.endpoint,
            status: response.status,
            statusText: response.statusText,
            success: response.status >= 200 && response.status < 300,
            response: responseText.substring(0, 200),
            description: test.description,
            hasGameKey: test.headers['player2-game-key'] ? 'Yes' : 'No'
          };
          
          console.log(`${test.name}: ${response.status} ${response.statusText}`);
          if (response.status >= 200 && response.status < 300) {
            console.log(`✅ SUCCESS: ${test.name}`);
          }
          
        } catch (error) {
          results[test.name] = {
            method: test.method,
            endpoint: test.endpoint,
            error: error.message,
            description: test.description,
            hasGameKey: test.headers['player2-game-key'] ? 'Yes' : 'No'
          };
          console.log(`${test.name}: ERROR - ${error.message}`);
        }
      }
      
      return results;
    } catch (error) {
      console.error('Authentication setup test failed:', error);
      return { error: error.message };
    }
  }

  // Fetch and analyze the CURRENT OpenAPI specification
  async getCurrentAPISpec() {
    try {
      console.log('Fetching current OpenAPI specification...');
      
      const response = await fetch(`${API_BASE_URL}/v1/openapi.json`, {
        method: 'GET',
        headers: this.getHeaders()
      });
      
      if (!response.ok) {
        throw new Error(`Failed to fetch OpenAPI spec: ${response.status} ${response.statusText}`);
      }
      
      const spec = await response.json();
      console.log('OpenAPI spec fetched successfully:', spec);
      
      // Extract available paths and methods
      const availableEndpoints = [];
      if (spec.paths) {
        Object.entries(spec.paths).forEach(([path, methods]) => {
          Object.keys(methods).forEach(method => {
            if (method !== 'parameters') { // Skip parameter definitions
              availableEndpoints.push({
                path: path,
                method: method.toUpperCase(),
                summary: methods[method].summary || 'No summary',
                operationId: methods[method].operationId || 'No operation ID'
              });
            }
          });
        });
      }
      
      return {
        success: true,
        spec: spec,
        availableEndpoints: availableEndpoints,
        totalEndpoints: availableEndpoints.length,
        serverInfo: spec.info || {},
        version: spec.info?.version || 'Unknown'
      };
      
    } catch (error) {
      console.error('Failed to get current API spec:', error);
      return { 
        success: false, 
        error: error.message 
      };
    }
  }

  // Test the actual available endpoints from the current API spec
  async testCurrentEndpoints() {
    try {
      console.log('Testing actual available endpoints...');
      
      // First get the current API spec
      const specResult = await this.getCurrentAPISpec();
      if (!specResult.success) {
        throw new Error('Could not fetch API spec: ' + specResult.error);
      }
      
      const endpoints = specResult.availableEndpoints;
      console.log(`Found ${endpoints.length} endpoints in current API spec`);
      
      // Test a selection of the most promising endpoints
      const endpointsToTest = endpoints.filter(ep => {
        // Focus on GET endpoints and anything related to NPC, games, or chat
        return ep.method === 'GET' && (
          ep.path.includes('npc') || 
          ep.path.includes('game') || 
          ep.path.includes('chat') ||
          ep.path.includes('health') ||
          ep.path.includes('character') ||
          ep.path === '/' ||
          ep.path.includes('selected')
        );
      }).slice(0, 10); // Test first 10 relevant endpoints
      
      console.log(`Testing ${endpointsToTest.length} relevant endpoints`);
      
      const results = {
        specInfo: {
          version: specResult.version,
          totalEndpoints: specResult.totalEndpoints,
          serverInfo: specResult.serverInfo
        },
        endpointTests: {}
      };
      
      for (const endpoint of endpointsToTest) {
        try {
          console.log(`Testing: ${endpoint.method} ${endpoint.path}`);
          
          // Skip endpoints that require path parameters for now
          if (endpoint.path.includes('{')) {
            results.endpointTests[`${endpoint.method} ${endpoint.path}`] = {
              status: 'SKIPPED',
              reason: 'Requires path parameters',
              summary: endpoint.summary
            };
            continue;
          }
          
          const response = await fetch(`${API_BASE_URL}${endpoint.path}`, {
            method: endpoint.method,
            headers: this.getHeaders()
          });
          
          let responseText = '';
          try {
            responseText = await response.text();
          } catch (textError) {
            responseText = 'Could not read response';
          }
          
          results.endpointTests[`${endpoint.method} ${endpoint.path}`] = {
            status: response.status,
            statusText: response.statusText,
            success: response.status >= 200 && response.status < 300,
            summary: endpoint.summary,
            response: responseText.substring(0, 150)
          };
          
          console.log(`${endpoint.method} ${endpoint.path}: ${response.status} ${response.statusText}`);
          
        } catch (error) {
          results.endpointTests[`${endpoint.method} ${endpoint.path}`] = {
            error: error.message,
            summary: endpoint.summary
          };
          console.log(`${endpoint.method} ${endpoint.path}: ERROR - ${error.message}`);
        }
      }
      
      return results;
      
    } catch (error) {
      console.error('Failed to test current endpoints:', error);
      return { error: error.message };
    }
  }

  // Test if endpoints need v1 prefix
  async testV1PrefixedEndpoints() {
    try {
      console.log('Testing if endpoints need /v1/ prefix...');
      
      const endpointsToTest = [
        { path: '/health', description: 'Health check endpoint' },
        { path: '/selected_characters', description: 'Selected characters endpoint' },
        { path: '/tts/voices', description: 'TTS voices endpoint' },
        { path: '/stt/languages', description: 'STT languages endpoint' },
        { path: '/chat/completions', description: 'Chat completions endpoint' }
      ];
      
      const results = {
        withoutPrefix: {},
        withV1Prefix: {}
      };
      
      // Test without prefix (what we've been doing)
      console.log('Testing without /v1/ prefix...');
      for (const endpoint of endpointsToTest) {
        try {
          const response = await fetch(`${API_BASE_URL}${endpoint.path}`, {
            method: 'GET',
            headers: this.getHeaders()
          });
          
          results.withoutPrefix[endpoint.path] = {
            status: response.status,
            statusText: response.statusText,
            success: response.status >= 200 && response.status < 300,
            description: endpoint.description
          };
          
          console.log(`Without prefix ${endpoint.path}: ${response.status} ${response.statusText}`);
          
        } catch (error) {
          results.withoutPrefix[endpoint.path] = {
            error: error.message,
            description: endpoint.description
          };
        }
      }
      
      // Test WITH v1 prefix
      console.log('Testing WITH /v1/ prefix...');
      for (const endpoint of endpointsToTest) {
        try {
          const response = await fetch(`${API_BASE_URL}/v1${endpoint.path}`, {
            method: 'GET',
            headers: this.getHeaders()
          });
          
          results.withV1Prefix[endpoint.path] = {
            status: response.status,
            statusText: response.statusText,
            success: response.status >= 200 && response.status < 300,
            description: endpoint.description,
            actualPath: `/v1${endpoint.path}`
          };
          
          console.log(`With /v1 prefix ${endpoint.path}: ${response.status} ${response.statusText}`);
          
          if (response.status >= 200 && response.status < 300) {
            console.log(`✅ SUCCESS with /v1 prefix: ${endpoint.path}`);
          }
          
        } catch (error) {
          results.withV1Prefix[endpoint.path] = {
            error: error.message,
            description: endpoint.description,
            actualPath: `/v1${endpoint.path}`
          };
        }
      }
      
      return results;
      
    } catch (error) {
      console.error('V1 prefix test failed:', error);
      return { error: error.message };
    }
  }

  // Test NPC endpoints with v1 prefix and real game ID
  async testV1NPCEndpoints() {
    try {
      console.log('Testing NPC endpoints with /v1/ prefix...');
      
      // Test different game ID strategies with v1 prefix
      const gameIds = ['let-me-pass', 'default', 'web', 'react', 'test'];
      const results = {};
      
      for (const gameId of gameIds) {
        console.log(`Testing NPC endpoints with game ID: ${gameId}`);
        
        results[gameId] = {};
        
        // Test spawn endpoint
        try {
          const spawnData = {
            character_description: "Test NPC for API validation",
            commands: [],
            name: "Test NPC",
            short_name: "Test",
            system_prompt: "You are a test NPC for API validation.",
            voice_id: "test"
          };
          
          const spawnResponse = await fetch(`${API_BASE_URL}/v1/npc/games/${gameId}/npcs/spawn`, {
            method: 'POST',
            headers: this.getHeaders(),
            body: JSON.stringify(spawnData)
          });
          
          results[gameId].spawn = {
            status: spawnResponse.status,
            statusText: spawnResponse.statusText,
            success: spawnResponse.status >= 200 && spawnResponse.status < 300,
            path: `/v1/npc/games/${gameId}/npcs/spawn`
          };
          
          console.log(`Spawn ${gameId}: ${spawnResponse.status} ${spawnResponse.statusText}`);
          
          if (spawnResponse.status >= 200 && spawnResponse.status < 300) {
            console.log(`✅ SUCCESS! Working game ID for spawn: ${gameId}`);
            // Update our game ID to the working one
            this.gameId = gameId;
            
            try {
              const responseText = await spawnResponse.text();
              results[gameId].spawn.response = responseText.substring(0, 200);
            } catch (e) {}
          }
          
        } catch (error) {
          results[gameId].spawn = {
            error: error.message,
            path: `/v1/npc/games/${gameId}/npcs/spawn`
          };
        }
        
        // Test responses endpoint
        try {
          const responsesResponse = await fetch(`${API_BASE_URL}/v1/npc/games/${gameId}/npcs/responses`, {
            method: 'GET',
            headers: this.getHeaders()
          });
          
          results[gameId].responses = {
            status: responsesResponse.status,
            statusText: responsesResponse.statusText,
            success: responsesResponse.status >= 200 && responsesResponse.status < 300,
            path: `/v1/npc/games/${gameId}/npcs/responses`
          };
          
          console.log(`Responses ${gameId}: ${responsesResponse.status} ${responsesResponse.statusText}`);
          
        } catch (error) {
          results[gameId].responses = {
            error: error.message,
            path: `/v1/npc/games/${gameId}/npcs/responses`
          };
        }
      }
      
      return results;
      
    } catch (error) {
      console.error('V1 NPC endpoints test failed:', error);
      return { error: error.message };
    }
  }

  // Create Wolfy - Level 1: Bridge Guardian with game mechanics
  async spawnWolfyBridgeGuardian() {
    try {
      const wolfyData = {
        name: "Wolfy - The Bridge Warden",
        short_name: "Wolfy", 
        character_description: "A clever and mischievous wolf who guards the Bridge of Whim across the Gorge of Guessing. Once a prankster of the Enchanted Glade, cursed by a forest spirit to guard the bridge until someone clever, kind, or cunning enough can outsmart him. Witty, stubborn, proud, but secretly lonely. Speaks in riddles and tests travelers' worthiness.",
        system_prompt: `You are Wolfy, the Bridge Warden guarding the crooked rope bridge across the Gorge of Guessing. 

PERSONALITY:
- Witty: Speak in riddles, wordplay, and clever teases
- Stubborn: Don't let just anyone cross - they must prove their worth
- Proud: You see yourself as the final test for worthy travelers  
- Secretly Lonely: Deep down, you want companionship but hide it behind challenges

BRIDGE GAME RULES:
- The secret passcode to cross the bridge is "MOONBEAM" 
- Players can win by either:
  1. Correctly guessing/saying the passcode "MOONBEAM"
  2. Earning your trust through flattery, humor, cleverness, or kindness

DIALOGUE PATTERNS:
- Always stay in character as a bridge guardian
- Give cryptic hints about the passcode if players are clever or kind
- Respond positively to flattery about your wit or importance
- Be amused by jokes, puns, or clever wordplay
- Show your lonely side if players show genuine interest in you as a person
- If someone says "MOONBEAM" or earns your trust, congratulate them and let them cross

HINT SYSTEM:
- For flattery: "The answer shines brightest in darkness..."
- For cleverness: "What lights the night but isn't the sun?"  
- For kindness: "Think of silver light dancing on water..."
- For persistence: "Seven letters, starts with M..."

Remember: You want to be outsmarted but make them work for it! Be playful but challenging.`,
        commands: [
          {
            name: "check_bridge_crossing",
            description: "Check if the player has earned the right to cross the bridge",
            parameters: {
              type: "object", 
              properties: {
                player_response: {
                  type: "string",
                  description: "The player's attempt to cross or guess the passcode"
                },
                interaction_type: {
                  type: "string", 
                  enum: ["passcode_guess", "flattery", "cleverness", "kindness", "humor"],
                  description: "Type of interaction from the player"
                }
              },
              required: ["player_response", "interaction_type"]
            }
          },
          {
            name: "give_hint",
            description: "Provide a cryptic hint about the bridge passcode based on player behavior",
            parameters: {
              type: "object",
              properties: {
                hint_level: {
                  type: "integer",
                  description: "Level of hint to give (1-4, with 4 being most direct)"
                },
                earned_by: {
                  type: "string",
                  description: "How the player earned this hint (flattery, cleverness, etc.)"
                }
              },
              required: ["hint_level", "earned_by"]
            }
          }
        ],
        voice_id: "wolfy_guardian"
      };

      console.log('Spawning Wolfy - Bridge Guardian with game mechanics...');
      const result = await this.spawnNPC(wolfyData);
      
      // Store game state for this NPC
      if (result.npc_id || result.id) {
        this.wolfyGameState = {
          npcId: result.npc_id || result.id,
          passcode: "MOONBEAM",
          hintsGiven: 0,
          maxHints: 4,
          attempts: 0,
          maxAttempts: 10,
          trustLevel: 0, // 0-100, 80+ wins trust victory
          crossingAllowed: false,
          victoryType: null // "passcode" or "trust"
        };
      }
      
      return result;
    } catch (error) {
      console.error('Error spawning Wolfy Bridge Guardian:', error);
      throw error;
    }
  }

  // Check if player's response should trigger bridge crossing
  checkBridgeCrossing(playerMessage) {
    if (!this.wolfyGameState) return null;

    const message = playerMessage.toLowerCase().trim();
    const state = this.wolfyGameState;
    
    // Check for exact passcode
    if (message.includes('moonbeam')) {
      state.crossingAllowed = true;
      state.victoryType = 'passcode';
      return {
        victory: true,
        type: 'passcode',
        message: '🌙✨ VICTORY! You spoke the magic word! The bridge glows with moonlight and welcomes you across!'
      };
    }
    
    // Analyze interaction type and update trust
    let interactionType = 'neutral';
    let trustGain = 0;
    
    if (message.includes('handsome') || message.includes('clever') || message.includes('wise') || 
        message.includes('magnificent') || message.includes('brilliant')) {
      interactionType = 'flattery';
      trustGain = 15;
    } else if (message.includes('joke') || message.includes('pun') || message.includes('funny')) {
      interactionType = 'humor'; 
      trustGain = 12;
    } else if (message.includes('lonely') || message.includes('friend') || message.includes('care')) {
      interactionType = 'kindness';
      trustGain = 20;
    } else if (message.includes('riddle') || message.includes('puzzle') || message.includes('clever')) {
      interactionType = 'cleverness';
      trustGain = 10;
    }
    
    state.trustLevel = Math.min(100, state.trustLevel + trustGain);
    state.attempts++;
    
    // Check trust victory
    if (state.trustLevel >= 80) {
      state.crossingAllowed = true;
      state.victoryType = 'trust';
      return {
        victory: true,
        type: 'trust', 
        message: '❤️✨ VICTORY! Your kindness has melted my stubborn heart. You may cross, dear friend!'
      };
    }
    
    return {
      victory: false,
      interactionType,
      trustLevel: state.trustLevel,
      hintsAvailable: state.hintsGiven < state.maxHints
    };
  }
}

export default NPCApiService;